#ifndef ENERGY_DATA
#define ENERGY_DATA

#define A 0
#define T 1
#define G 2
#define C 3
#define SPACE 4
#define N 4

#define  MAX_LOOP 30

#endif

